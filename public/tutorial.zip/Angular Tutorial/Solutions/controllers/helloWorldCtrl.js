app.controller("helloWorldCtrl", function($scope){
	$scope.msg = "hello world!";
})