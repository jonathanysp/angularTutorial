app.directive('todoItem', function() {
	return {
		template: '{{item}}'
	};
});